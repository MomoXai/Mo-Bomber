# Email-bomber
===============
before opening the tool type this command :

chmod +x E-bomber.py

//================================\\

Momo Page : https://www.facebook.com/Momo-1173341422763318/

TikusPintar Page : https://www.facebook.com/OfficialTikusPintar/

Youtube Channel : https://www.youtube.com/channel/UCTuwKI5dxcj63ijpRLc7zrA/

Website : http://www.tikuspintar.ga/

//================================\\
